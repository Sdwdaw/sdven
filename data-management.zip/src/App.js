import React, { Component } from 'react';

import './resources/styles.css';

import Header from './components/header_footer/Header';
// import Footer from './components/header_footer/Footer';

import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

import Home from './components/elements/Home';
import ScriptCatalog from './components/elements/ScriptCatalog';
import InstrumentEditor from './components/elements/InstrumentEditor';
import DataLookupTool from './components/elements/DatalookupTool';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Router>
          <Header/>

          <div className="content">
          
            <Switch>
              <Route exact path="/" component={Home} />
              <Route exact path="/script_catalog" component={ScriptCatalog} />
              <Route exact path="/instrument_editor" component={InstrumentEditor} />
              <Route exact path="/data_lokup_tool" component={DataLookupTool} />
            </Switch>
          
          </div>
        
        </Router>

        {/* <Element name="featured">
          <Featured/>
        </Element>

        <Element name="venuenfo">
          <VunueNfo/>
        </Element>
        
        <Element name="highlights">
          <Highlight/>
        </Element>
        
        <Element name="pricing">
          <Pricing/>
        </Element>

        <Element name="location">
          <Location/>
        </Element>
         */}
        {/* <Footer/> */}
      </div>
    );
  }
}

export default App;