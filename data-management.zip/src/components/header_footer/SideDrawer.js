import React from 'react';

import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import { Link } from 'react-router-dom';

const linkStyle = {
    textDecoration: 'none', color: "#0d4497"
}

const SideDrawer = (props) => {
   
    return (
        <Drawer
            anchor="right"
            open={props.open}
            onClose={()=> props.onClose(false)}
        >
            <List component="nav">
                <ListItem>
                    <Link to="/" style={linkStyle}>Home</Link>
                </ListItem>
                <ListItem>
                    <Link to="/script_catalog" style={linkStyle}>Script Catalog</Link>
                </ListItem>
                <ListItem>
                    <Link to="/instrument_editor" style={linkStyle}>Instrument Editor</Link>
                </ListItem>
                <ListItem>
                    <Link to="/data_lookup_tool" style={linkStyle}>Data Lookup Tool</Link>
                </ListItem>
            </List>
        </Drawer>
    );
};

export default SideDrawer;