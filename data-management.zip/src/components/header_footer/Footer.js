import React from 'react';
import Fade from 'react-reveal/Fade';

const Footer = () => {
    return (
        <footer className="footer-header">
            <Fade delay={400}>
                <div className="footer-text">Data Management Work Bench</div>
                <div className="footer_copyright">
                    Tudor {new Date().getFullYear()}. All rights reserved.
                </div>
            </Fade>
        </footer>
    );
};

export default Footer;
