import React, { Component } from 'react'

export default class InstrumentEditor extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
