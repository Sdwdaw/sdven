import React, { Component } from 'react'
import { Link } from 'react-router-dom';

import Panel from '../panel/Panel';

export default class Home extends Component {
  
  render() {
    const linkStyle = {
      textDecoration: 'none'
    }
    
    return (
      <div className="home">
        <Link to="/script_catalog" style={linkStyle}>
          <Panel name = "Script Catalog" url = "/script_catalog" desc = "some description"/>
        </Link>
        <Link to="/instrument_editor" style={linkStyle}>
          <Panel name = "Instrument editor" url = "/instrument_editor" desc = "some description"/>
        </Link>
        <Link to="/data_lokup_tool" style={linkStyle}>
          <Panel name = "Data Lookup tool" url = "/data_lokup_tool" desc = "some description"/>
        </Link>
      </div>
    )
  }
}
