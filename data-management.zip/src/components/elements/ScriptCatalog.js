import React, { Component } from 'react';
import axios from 'axios';

export default class ScriptCatalog extends Component {

  componentDidMount() {
    axios.get('http://localhost:5082/v1/myjsonws')
    .then(response => {
      console.log(response.data);
    })
    .catch(error => {
      console.log(error);
    })
  }

  render() {
    return (
      
      <div>
        this is script catalog        
      </div>
    )
  }
}
