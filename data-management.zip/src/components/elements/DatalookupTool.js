import React, { Component } from 'react'

export default class DatalookupTool extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
