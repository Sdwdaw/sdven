import React, {Component} from 'react';
import Fade from 'react-reveal/Fade';

class Panel extends Component {
  render () {
    return (
      <Fade>
          <div className="center_wrapper">
              <h2>{this.props.name}</h2>
              <hr/>
              <div className="panel_description">
                <p>{this.props.url}</p>
                <p>{this.props.desc}</p>
              </div>
          </div>
      </Fade>
    )
  }
}
// const Panel = (props) => {
//     return (
//         <Fade>
//             <div className="center_wrapper">
//                 <h2>{props.name}</h2>
//                 <div className="highlight_description">
                
//                 </div>
//             </div>
//         </Fade>
//     );
// };

export default Panel;